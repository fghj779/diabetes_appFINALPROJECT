from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# 학습된 모델 로드
model = joblib.load('diabetes_model.pkl')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # 입력 데이터 받기
    int_features = [float(x) for x in request.form.values()]
    final_features = [np.array(int_features)]
    
    # 예측
    prediction_proba = model.predict_proba(final_features)
    output = round(prediction_proba[0][1] * 100, 2)
    
    return render_template('index.html', prediction_text=f'당뇨병 발병 확률: {output}%')

if __name__ == "__main__":
    app.run(debug=True)

