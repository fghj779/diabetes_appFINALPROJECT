import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

# 데이터 불러오기 및 전처리
data = pd.read_csv('diabetes.csv')
X = data.drop('Outcome', axis=1)
y = data['Outcome']

# 데이터 증강
def augment_data(X, y, factor=2):
    X_augmented = pd.concat([X] * factor, ignore_index=True)
    y_augmented = pd.concat([y] * factor, ignore_index=True)
    noise = np.random.normal(0, 0.1, X_augmented.shape)
    X_augmented += noise
    return X_augmented, y_augmented

X_augmented, y_augmented = augment_data(X, y, factor=5)

# 데이터 분할
X_train, X_test, y_train, y_test = train_test_split(X_augmented, y_augmented, test_size=0.2, random_state=42)

# 모델 학습
model = RandomForestClassifier()
model.fit(X_train, y_train)

# 모델 저장
joblib.dump(model, 'diabetes_model.pkl')
